package com.example.soap;
import java.io.BufferedReader;
import java.io.InputStreamReader;

import com.example.soap.ATMInterface;
import com.example.soap.ServerService;

public class SoapClient 
{
ServerService s=new ServerService();
ATMInterface atm=s.getServerPort();
private String pw;
private int acc1;
private double amount;
private double result1;
private boolean found;
private char c;
 public static void main(String [] args)
 {
	 SoapClient obj=new SoapClient();
	 obj.service();
 }
 public void service()
 {
	 try
     {
          BufferedReader stdin=new BufferedReader (
                     new InputStreamReader (System.in));
          do
          {
             System.out.print("Please enter password: ");
             pw=stdin.readLine().trim();
             found=atm.searchpw(pw);
             if(found)
             {
                 while(true)
                 {
                     System.out.println("Transaction Types: D = Deposit\n"
                                                     +"\t\t   W = Withdraw\n"
                                                     +"\t\t   B = Balance\n"
                                                     +"\t\t   Q = Quit");
                     System.out.println("Please enter your transaction:");
                     c=stdin.readLine().charAt(0);
                     System.out.flush();
                     switch(c)
                     {
                         case 'D':
                             System.out.print("Enter ACCNUM: ");
                             acc1=Integer.parseInt(stdin.readLine().trim());
                             System.out.print("Enter amount: ");
                             amount=Double.parseDouble(stdin.readLine().trim());
                             result1=atm.deposit(acc1, amount);
                             if(result1>=0)
                             {
                           	  System.out.println("ACC: "+acc1+"\t\tNew Bal: "+result1);
                             	  System.out.println("Deposition Successfull\n");	
                             }  
                             else
                                 System.out.println("ACC not found.");
                             break;
                         case 'W':
                       	  System.out.print("Enter ACCNUM: ");
                       	  acc1=Integer.parseInt(stdin.readLine().trim());
                       	  System.out.print("Enter amount: ");
                       	  amount=Double.parseDouble(stdin.readLine().trim());
                       	  result1=atm.withdraw(acc1, amount);
                       	  if(result1>=0)
                       	  {
                       		  System.out.println("ACC: "+acc1+"\t\t New Bal:"+result1);
                       		  System.out.println("Withdraw Successfull");
                       	  }
                       	  else 
                       		  System.out.println("ACC not found");
                       	  break;
                         case 'B':
                       	  System.out.print("Enter the Accnum:");
                       	  acc1=Integer.parseInt(stdin.readLine().trim());
                       	  result1=atm.balance(acc1);
                       	  if(result1>=0)
                       		  System.out.println("The Balance in Acc: "+acc1+ "is "+result1);
                       	  else
                       		  System.out.println("Acc not found");
                       	  break;
                       	  
                         case 'Q':
                         System.exit(0);

                     }
                 }
             }
  	     } while(!found);
	}
     catch (Exception e) 
     {
   	  
     }
 }
}
