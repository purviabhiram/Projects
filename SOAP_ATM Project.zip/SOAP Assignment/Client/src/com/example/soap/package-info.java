@javax.xml.bind.annotation.XmlSchema(namespace = "http://soap.example.com/")
package com.example.soap;
