package com.example.soap;
import javax.jws.*;
@WebService
public interface ATMInterface 
{
	@WebMethod
	boolean searchpw(String pwd);
	@WebMethod
	double deposit(int Accnum, double amount);
	@WebMethod
	double withdraw(int Accnum,double amount);
	@WebMethod
	double balance(int Accnum);
}
