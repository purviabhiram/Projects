package com.example.soap;
import javax.xml.ws.*;
public class Publisher 
{
	public static void main(String [] args)
	{
		Endpoint.publish("http://localhost:8081/WS/ATMInterface", new Server());
	}
}
