package com.example.soap;
import javax.jws.*;

@WebService(endpointInterface="com.example.soap.ATMInterface")
public class Server implements ATMInterface
{
	public static final int N=10;
	private boolean found;
	private String pw;
	private double accArr[];
	private int i;

		public Server()
		{
			pw="888";
			accArr=new double[N];
			for(i=0;i<N;i++)
			{
				accArr[i]=0;
			}
		}
		public static void main(String [] args)
		{
			Server obj=new Server();
		}
		@WebMethod
		public boolean searchpw(String pw)
		{
			if(pw.equals(this.pw))
			{
				found=true;
			}
			return found;
		}
		@Override
		@WebMethod
		public double deposit(int Accnum, double amount) 
		{
			System.out.println("Deposit "+amount+" in Acc "+Accnum);
			for(i=0;i<N;i++)
			{
				if(Accnum>0&&Accnum<11)
				{
					accArr[Accnum-1]+=amount;
					System.out.println("deposit Successful\n");
					return accArr[Accnum-1];
				}
			}	
			return -1;
		}
		@Override
		@WebMethod
		public double withdraw(int Accnum, double amount) 
		{
			System.out.println("Withdraw "+amount+" from Acc "+Accnum);
			for(i=0;i<N;i++)
			{
				if(Accnum>0&&Accnum<11)
				{
					accArr[Accnum-1]-=amount;
					System.out.println("Withdraw Successful\n");
					return accArr[Accnum-1];
				}
			}	
			return -1;
		}
		@Override
		@WebMethod
		public double balance(int Accnum) 
		{
			System.out.println("Balance in Acc "+Accnum+" is\n");
			for(i=0;i<N;i++)
			{
				if(Accnum>0&&Accnum<11)
				{
					return accArr[Accnum-1];
				}
			}
			return -1;
		}
}
