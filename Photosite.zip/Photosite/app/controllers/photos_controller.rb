class PhotosController < ApplicationController
  def index
  @users= User.find(params[:id])
  @photo=@users.photos

   def show
     @users1=User.find(params[:user_id])
     @photos1=@users1.photos
end

  end
  def display
    @user=User.find(params[:user_id])
    @photos = @user.photos
  end
end
